<template>
  <nav class="navbar">
    <div class="navbar-left">
      <!-- ✅ ใช้ Lucide icon แทน &#9776; -->
      <button class="hamburger">
        <Menu :size="22" />
      </button>
     <img src="../../assets/logo-psu.png" alt="PSU Logo" class="logo-psu" />
      <span class="navbar-title">งานสร้างเสริมสุขภาพ คณะแพทยศาสตร์ มหาวิทยาลัยสงขลานครินทร์</span>
    </div>

    <div class="navbar-right">
      <!-- ✅ ใช้ Lucide icon แทน emoji -->
      <a href="#" class="nav-link">
        <Home :size="18" /> หน้าหลัก
      </a>

      <a href="#" class="nav-link nav-ticket">
        <Ticket :size="18" />
        <span class="badge">9</span>
      </a>

      <a href="#" class="nav-link nav-reserve">
        <CalendarDays :size="18" /> จอง/ลงชื่อใช้สนาม
      </a>
    </div>
  </nav>
</template>

<script setup lang="ts">
import { Menu, Ticket, CalendarDays, Home } from 'lucide-vue-next'
</script>

<style scoped>
.navbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #ffffff;
  padding: 1px 20px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  position: sticky;
  top: 0;
  z-index: 100;
}

.navbar-left {
  display: flex;
  align-items: center;
  gap: 10px;
}

.hamburger {
  background: none;
  border: none;
  cursor: pointer;
  color: #333;
  display: flex;
  align-items: center;
}

.logo-psu {
  height: 60px;
  object-fit: contain;
}

.navbar-title {
  font-size: 15px;
  color: #333;
  font-weight: 500;
  max-width: 700px; /* ✅ แก้จาก max: width 700px */
}

.navbar-right {
  display: flex;
  align-items: center;
  gap: 16px;
}

.nav-link {
  display: flex;
  align-items: center;
  gap: 6px;
  text-decoration: none;
  color: #333;
  font-size: 15px;
  font-weight: 500;
  padding: 6px 12px;
  border-radius: 6px;
  transition: background 0.2s;
}

.nav-link:hover {
  background: #f0f0f0;
}

.nav-ticket {
  position: relative;
}

.badge {
  position: absolute;
  top: 0px;
  right: 2px;
  background: #e53935;
  color: white;
  font-size: 10px;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
<template>
  <div class="reserve-page">
    <!-- Left Panel -->
    <div class="left-panel">
      <h1>Reserve Court</h1>
      <p class="subtitle">select a date and time slot</p>

      <!-- Reserve Date Card -->
      <div class="info-card">
        <p class="card-label">Reserve Date</p>
        <p class="card-sub">Booking is only available for today</p>
        <button class="date-btn" :style="{ backgroundColor: todayColor }">
          <CalendarDays :size="16" />
          {{ todayFormatted }}
        </button>
        <p class="card-sub">Advance booking not available.</p>
      </div>

      <!-- User Info Card -->
      <div class="info-card">
        <p class="card-label">User Information</p>
        <div class="user-row">
          <User :size="16" /> <span>Suwanon Choojan</span>
        </div>
        <div class="user-row">
          <MonitorSmartphone :size="16" /> <span>IT</span>
        </div>
      </div>
    </div>

    <!-- Right Panel -->
    <div class="right-panel">
      <!-- Sport Tabs -->
      <div class="sport-tabs">
        <button
          :class="['tab-btn', selectedSport === 'badminton' ? 'active' : '']"
          @click="switchSport('badminton')"
        >
          <Feather :size="20" />
          <span>Badminton</span>
        </button>
        <button
          :class="['tab-btn', selectedSport === 'football' ? 'active' : '']"
          @click="switchSport('football')"
        >
          <CircleDot :size="20" />
          <span>Football</span>
        </button>
      </div>

      <!-- Courts -->
      <div class="courts-list">
        <div v-for="court in currentCourts" :key="court.name" class="court-card">
          <h3>{{ court.name }}</h3>
          <div class="time-slots">
            <button
              v-for="slot in timeSlots"
              :key="slot"
              :class="['slot-btn', isSelected(court.name, slot) ? 'selected' : '']"
              @click="toggleSlot(court.name, slot)"
            >
              {{ slot }}
            </button>
          </div>
        </div>
      </div>

      <!-- Confirm Button -->
      <div class="confirm-row">
        <button class="confirm-btn" @click="confirmReservation">
          CONFIRM <ArrowRight :size="18" />
        </button>
      </div>
    </div>
  </div>

   <Transition name="fade">
    <div v-if="alertMsg" class="modal-overlay" @click="alertMsg = ''">
      <div class="modal-box" @click.stop>
        <div class="modal-icon">
          <AlertCircle :size="40" color="#e65100" />
        </div>
        <p class="modal-msg">{{ alertMsg }}</p>
        <button class="modal-close" @click="alertMsg = ''">ตกลง</button>
      </div>
    </div>
  </Transition>

</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import {
  CalendarDays,
  User,
  MonitorSmartphone,
  Feather,
  CircleDot,
  ArrowRight,
  AlertCircle,
} from 'lucide-vue-next'

// ===== วันที่ + สีตามวัน =====
const todayDay = computed(() => new Date().getDay())

const todayFormatted = computed(() =>
  new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  })
)

const dayColors: Record<number, string> = {
  0: '#EF5350', // อาทิตย์ — แดง
  1: '#FFB300', // จันทร์ — เหลือง
  2: '#E91E63', // อังคาร — ชมพู
  3: '#4CAF50', // พุธ — เขียว
  4: '#FF7043', // พฤหัส — ส้ม
  5: '#42A5F5', // ศุกร์ — ฟ้า
  6: '#AB47BC', // เสาร์ — ม่วง
}

const todayColor = computed(() => dayColors[todayDay.value])

// ===== Sport =====
const selectedSport = ref('badminton')

const badmintonCourts = [
  { name: 'Badminton court A' },
  { name: 'Badminton court B' },
  { name: 'Badminton court C' },
  { name: 'Badminton court D' },
]

const footballCourts = [
  { name: 'Football Arena A' },
  { name: 'Football Arena B' },
]

const currentCourts = computed(() =>
  selectedSport.value === 'badminton' ? badmintonCourts : footballCourts
)

const timeSlots = [
  '14.00 - 15.00',
  '15.00 - 16.00',
  '16.00 - 17.00',
  '17.00 - 18.00',
  '18.00 - 19.00',
  '19.00 - 20.00',
  '20.00 - 21.00',
  '21.00 - 22.00',
]

// ===== Slots =====
const selectedSlots = ref<{ court: string; slot: string }[]>([])
const alertMsg = ref('')

function switchSport(sport: string) {
  selectedSport.value = sport
  selectedSlots.value = []
  alertMsg.value = ''
}

function isSelected(court: string, slot: string) {
  return selectedSlots.value.some(s => s.court === court && s.slot === slot)
}

// ✅ แปลง "14.00 - 15.00" → 14
function slotToHour(slot: string): number {
  return parseInt(slot.split('.')[0].trim())
}

function toggleSlot(court: string, slot: string) {
  alertMsg.value = ''

  // คลิกซ้ำ → ยกเลิก
  const index = selectedSlots.value.findIndex(
    s => s.court === court && s.slot === slot
  )
  if (index >= 0) {
    selectedSlots.value.splice(index, 1)
    return
  }

  // ✅ เช็ค total ก่อนเลย ห้ามเกิน 2 รวมทุกสนาม
  if (selectedSlots.value.length >= 2) {
    alertMsg.value = 'จองได้สูงสุด 2 ชั่วโมงเท่านั้น'
    return
  }

  // ✅ ถ้ามี slot อยู่แล้ว ต้องเป็นสนามเดียวกันและติดกัน
  if (selectedSlots.value.length === 1) {
    const existing = selectedSlots.value[0]

    // ✅ ต้องเป็นสนามเดียวกัน
    if (existing.court !== court) {
      alertMsg.value = 'กรุณาเลือกเวลาในสนามเดียวกันเท่านั้น'
      return
    }

    // ✅ ต้องติดกัน
    const existingHour = slotToHour(existing.slot)
    const newHour = slotToHour(slot)
    if (Math.abs(newHour - existingHour) !== 1) {
      alertMsg.value = 'กรุณาเลือกเวลาที่ติดกัน เช่น 14.00-15.00 และ 15.00-16.00'
      return
    }
  }

  selectedSlots.value.push({ court, slot })
}

function confirmReservation() {
  alertMsg.value = ''
  if (selectedSlots.value.length === 0) {
    alertMsg.value = 'กรุณาเลือกเวลาที่ต้องการ'
    return
  }
  alert(`จองสำเร็จ ${selectedSlots.value.length} ชั่วโมง`)
  selectedSlots.value = []
}
</script>

<style scoped>
.reserve-page {
  display: flex;
  gap: 32px;
  padding: 32px 40px;
  min-height: calc(100vh - 80px);
}

/* ===== LEFT ===== */
.left-panel {
  width: 280px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.left-panel h1 {
  font-size: 32px;
  font-weight: 700;
  color: #1a1a1a;
}

.subtitle {
  font-size: 14px;
  color: #888;
  margin-top: -12px;
}

.info-card {
  background: white;
  border-radius: 12px;
  padding: 16px 20px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}

.card-label {
  font-weight: 700;
  font-size: 15px;
  color: #1a1a1a;
}

.card-sub {
  font-size: 13px;
  color: #888;
}

.date-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  color: white;
  border: none;
  border-radius: 20px;
  padding: 8px 16px;
  font-size: 13px;
  font-weight: 600;
  cursor: default;
  width: fit-content;
}

.user-row {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 14px;
  color: #333;
}

/* ===== RIGHT ===== */
.right-panel {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.sport-tabs {
  display: flex;
  justify-content: center;
  gap: 60px;
  border-bottom: 2px solid #eee;
  padding-bottom: 8px;
}

.tab-btn {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  background: none;
  border: none;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  color: #aaa;
  padding: 8px 24px;
  border-bottom: 3px solid transparent;
  transition: all 0.2s;
}

.tab-btn.active {
  color: #1b5e20;
  border-bottom: 3px solid #1b5e20;
}

.courts-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.court-card {
  background: white;
  border-radius: 12px;
  padding: 20px 24px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}

.court-card h3 {
  font-size: 16px;
  font-weight: 700;
  color: #1a1a1a;
  margin-bottom: 14px;
}

.time-slots {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.slot-btn {
  border: 1.5px solid #2e7d32;
  background: white;
  color: #2e7d32;
  border-radius: 20px;
  padding: 6px 16px;
  font-size: 13px;
  cursor: pointer;
  transition: all 0.2s;
  font-weight: 500;
}

.slot-btn:hover {
  background: #e8f5e9;
}

.slot-btn.selected {
  background: #2e7d32;
  color: white;
}

.alert-box {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #fff3e0;
  border: 1px solid #ff9800;
  color: #e65100;
  border-radius: 8px;
  padding: 10px 16px;
  font-size: 14px;
  font-weight: 500;
}

.confirm-row {
  display: flex;
  justify-content: flex-end;
}

.confirm-btn {
  display: flex;
  align-items: center;
  gap: 10px;
  background: #1b5e20;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 12px 28px;
  font-size: 15px;
  font-weight: 700;
  cursor: pointer;
  letter-spacing: 1px;
  transition: background 0.2s;
}

.confirm-btn:hover {
  background: #2e7d32;
}

/* ===== Modal Alert ===== */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 999;
}

.modal-box {
  background: white;
  border-radius: 16px;
  padding: 32px 40px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
  min-width: 320px;
  max-width: 400px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.2);
  text-align: center;
}

.modal-icon {
  background: #fff3e0;
  border-radius: 50%;
  width: 72px;
  height: 72px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-msg {
  font-size: 16px;
  font-weight: 500;
  color: #333;
  line-height: 1.6;
}

.modal-close {
  background: #1b5e20;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 10px 32px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s;
  margin-top: 4px;
}

.modal-close:hover {
  background: #2e7d32;
}

/* ===== Transition ===== */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
<template>
  <HeroBanner @reserve="goToReserve" />
  <ReservationTable />
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'
import HeroBanner from '../components/home/HeroBanner.vue'
import ReservationTable from '../components/home/ReservationTable.vue'

const router = useRouter()

function goToReserve() {
  router.push('/reserve')
}
</script>
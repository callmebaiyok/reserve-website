<template>
  <div class="page-container" :style="{ backgroundImage: `url(${bgImage})` }">
    <NavBar />
    <main>
      <RouterView />
    </main>
    <FooterSection />
  </div>
</template>

<script setup lang="ts">
import NavBar from './components/common/NavBar.vue'
import FooterSection from './components/common/FooterSection.vue'
import bgImage from './assets/hero-bg.png'
</script>

<style scoped>
.page-container {
  width: 100%;
  min-height: 100vh;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  background-attachment: fixed;
}
</style>
<template>
  <div class="page-wrapper">
    <NavBarAdmin />

    <div class="main-content">
      <!-- Left Sidebar -->
      <aside class="sidebar section-card">
        <h2 class="sidebar-main-title">Admin Dashboard</h2>
        <p class="select-date-label">Select date</p>
        <p class="selected-date-display">Wed, Apr 22</p>

        <div class="calendar-widget">
          <div class="calendar-header">
            <span>April 2026 ∨</span>
            <div class="calendar-nav">
              <button class="cal-nav-btn">‹</button>
              <button class="cal-nav-btn">›</button>
            </div>
          </div>
          <div class="cal-weekdays">
            <span v-for="d in ['S','M','T','W','TH','F','S']" :key="d">{{ d }}</span>
          </div>
          <div class="calendar-grid">
            <span
              v-for="(dayNum, index) in calendarDays"
              :key="index"
              class="cal-day"
              :class="{ 'is-selected': dayNum === 22, 'is-empty': !dayNum }"
            >{{ dayNum || '' }}</span>
          </div>
        </div>
      </aside>

      <!-- Right Main Area -->
      <main class="schedule-area">
        <!-- Top: Add button -->
        <div class="top-bar">
          <button class="add-btn" @click="openAddModal">+ เพิ่มประเภทสนาม</button>
        </div>

        <!-- Court Types Table -->
        <section class="section-card table-section">
          <h2 class="section-title">จัดการประเภทสนาม</h2>
          <p class="section-sub">เพิ่ม / แก้ไข / ลบ ประเภทสนามกีฬา</p>

          <div v-if="loading" class="loading-bar"></div>

          <!-- Error Banner -->
          <div v-if="errorMsg" class="error-banner">
            ⚠️ {{ errorMsg }}
          </div>

          <table class="court-table">
            <thead>
              <tr>
                <th>ลำดับ</th>
                <th>ไอคอน</th>
                <th>ชื่อประเภทสนาม</th>
                <th>รายละเอียด</th>
                <th>จัดการ</th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="!loading && courtTypes.length === 0">
                <td colspan="5" class="empty-row">ไม่มีข้อมูลประเภทสนาม</td>
              </tr>
              <tr v-for="(type, index) in courtTypes" :key="type.courtTypeId">
                <td>{{ index + 1 }}</td>
                <td><span class="court-icon">{{ type.courtTypeId != null ? (iconMap[type.courtTypeId] || '🏟️') : '🏟️' }}</span></td>
                <td class="court-name-cell">{{ type.courtTypeName }}</td>
                <td class="court-desc-cell">{{ type.description }}</td>
                <td>
                  <div class="action-btns">
                    <button class="action-edit" @click="openEditModal(type)" title="แก้ไข">✏️</button>
                    <button class="action-delete" @click="type.courtTypeId != null && deleteCourtType(type.courtTypeId)" title="ลบ">🗑️</button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </section>

        <!-- Sub Courts Table -->
        <section class="section-card table-section sub-courts-section">
          <div class="sub-header">
            <div>
              <h2 class="section-title">สนามของแต่ละประเภท</h2>
              <p class="section-sub">จัดการสนามย่อยในแต่ละประเภท</p>
            </div>
            <div class="sub-controls">
              <div class="select-wrapper">
                <label>เลือกประเภทสนาม</label>
                <select v-model="selectedTypeId" class="type-select" @change="onSelectChange">
                  <option disabled :value="null">-- เลือกประเภทสนาม --</option>
                  <option v-for="ct in courtTypes" :key="ct.courtTypeId" :value="ct.courtTypeId">
                    {{ ct.courtTypeName }} ({{ ct.description }})
                  </option>
                </select>
              </div>
            </div>
          </div>

          <div v-if="loadingCourts" class="loading-bar"></div>

          <table class="court-table">
            <thead>
              <tr>
                <th>ลำดับ</th>
                <th>ชื่อสนาม</th>
                <th>เวลาให้บริการ</th>
                <th>สล็อต (นาที)</th>
                <th>ราคา (บาท)</th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="courts.length === 0">
                <td colspan="5" class="empty-row">ไม่มีข้อมูลสนาม หรือยังไม่ได้เลือกประเภทสนาม</td>
              </tr>
              <tr v-for="(court, index) in courts" :key="court.courtId">
                <td>{{ index + 1 }}</td>
                <td class="court-name-cell">{{ court.courtName }}</td>
                <td>{{ court.startReserveTime.slice(0,5) }} - {{ court.endReserveTime.slice(0,5) }} น.</td>
                <td>{{ court.slotTime }}</td>
                <td>{{ court.slotPrice }}</td>
              </tr>
            </tbody>
          </table>
        </section>
      </main>
    </div>

    <FooterSection />

    <!-- Add/Edit CourtType Modal -->
    <Transition name="fade">
      <div v-if="showModal" class="modal-overlay" @click="closeModal">
        <div class="modal-box" @click.stop>
          <div class="modal-header">
            <h3>{{ isEditing ? 'แก้ไขประเภทสนามกีฬา' : 'เพิ่มประเภทสนามกีฬา' }}</h3>
            <button class="modal-close" @click="closeModal">✕</button>
          </div>

          <div class="modal-body">
            <!-- Icon Picker -->
            <div class="form-group">
              <label>ไอคอน</label>
              <div class="icon-picker">
                <span
                  v-for="ic in iconOptions"
                  :key="ic"
                  class="icon-option"
                  :class="{ selected: selectedIcon === ic }"
                  @click="selectedIcon = ic"
                >{{ ic }}</span>
              </div>
            </div>

            <div class="form-group">
              <label>ชื่อประเภทสนาม *</label>
              <input v-model="form.courtTypeName" type="text" placeholder="เช่น สนามแบดมินตัน" />
            </div>

            <div class="form-group">
              <label>คำอธิบายสั้นๆ</label>
              <input v-model="form.description" type="text" placeholder="เช่น Badminton Court" />
            </div>

            <div class="form-group">
              <label>ลำดับการแสดงผล</label>
              <input v-model.number="form.sequence" type="number" min="1" />
            </div>

            <!-- Save Error -->
            <div v-if="saveError" class="error-banner">⚠️ {{ saveError }}</div>
          </div>

          <div class="modal-footer">
            <button class="btn-cancel" @click="closeModal">ยกเลิก</button>
            <button
              class="btn-confirm"
              :disabled="!form.courtTypeName || saving"
              @click="saveCourtType"
            >
              <span v-if="saving">กำลังบันทึก...</span>
              <span v-else>{{ isEditing ? 'บันทึกการแก้ไข' : 'เพิ่มประเภทสนาม' }}</span>
            </button>
          </div>
        </div>
      </div>
    </Transition>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { apiService, type CourtType, type Court } from '../service/apiServices'

// ─── State ───────────────────────────────────────────────────────────────────
const courtTypes   = ref<CourtType[]>([])
const courts       = ref<Court[]>([])
const selectedCourtType = ref<CourtType | null>(null)
const selectedTypeId    = ref<number | null>(null)
const loading      = ref(false)
const loadingCourts = ref(false)
const errorMsg     = ref('')

// ─── Modal State ──────────────────────────────────────────────────────────────
const showModal    = ref(false)
const isEditing    = ref(false)
const currentId    = ref<number | null>(null)
const saving       = ref(false)
const saveError    = ref('')
const selectedIcon = ref('🏟️')
const iconOptions  = ['🏸', '⚽', '🏀', '🏓', '🏋️', '🏊', '🎾', '🥊', '🏐', '⛳', '🏟️', '🏑', '🎱', '🤺', '🏄']

// ─── Icon Map (localStorage) ──────────────────────────────────────────────────
const ICON_MAP_KEY = 'courtTypeIconMap'
const loadIconMap = (): Record<number, string> => {
  try { return JSON.parse(localStorage.getItem(ICON_MAP_KEY) || '{}') } catch { return {} }
}
const saveIconMap = (map: Record<number, string>) => {
  localStorage.setItem(ICON_MAP_KEY, JSON.stringify(map))
}
const iconMap = ref<Record<number, string>>(loadIconMap())

const form = ref<CourtType>({
  courtTypeName: '',
  description: '',
  sequence: 1,
  imgUuid: 'b4099451-adff-439f-94d2-3357b273045a',
})

// ─── Calendar ─────────────────────────────────────────────────────────────────
const calendarDays: (number | null)[] = [
  null, null, null,
  1,2,3,4,5,6,7,8,9,10,
  11,12,13,14,15,16,17,18,19,20,
  21,22,23,24,25,26,27,28,29,30
]

// ─── API: ดึงประเภทสนามทั้งหมด ────────────────────────────────────────────────
const fetchCourtTypes = async () => {
  loading.value = true
  errorMsg.value = ''
  try {
    const res = await apiService.getAllCourtTypes()
    console.log('[fetchCourtTypes] response:', res)
    if (res.statusCode === 200) {
      courtTypes.value = res.data
    } else {
      errorMsg.value = `โหลดข้อมูลไม่สำเร็จ (statusCode: ${res.statusCode})`
    }
  } catch (error: any) {
    console.error('[fetchCourtTypes] error:', error)
    errorMsg.value = error?.message ?? 'ไม่สามารถเชื่อมต่อ API ได้ กรุณาลองใหม่อีกครั้ง'
  } finally {
    loading.value = false
  }
}

// ─── API: ดึงสนามย่อย ─────────────────────────────────────────────────────────
const selectCourtType = async (type: CourtType) => {
  selectedCourtType.value = type
  courts.value = []
  if (type.courtTypeId == null) return
  loadingCourts.value = true
  try {
    const res = await apiService.getCourtsByTypeId(type.courtTypeId)
    console.log('[getCourtsByTypeId] response:', res)
    if (res.statusCode === 200) {
      courts.value = res.data
    }
  } catch (error) {
    console.error('[getCourtsByTypeId] error:', error)
  } finally {
    loadingCourts.value = false
  }
}

const onSelectChange = () => {
  const found = courtTypes.value.find(ct => ct.courtTypeId === selectedTypeId.value)
  if (found) selectCourtType(found)
}

// ─── API: บันทึก ──────────────────────────────────────────────────────────────
const saveCourtType = async () => {
  saving.value = true
  saveError.value = ''
  try {
    const payload = { ...form.value }
    if (isEditing.value && currentId.value != null) {
      await apiService.updateCourtType(currentId.value, { ...payload, updatedBy: '12345' })
      iconMap.value[currentId.value] = selectedIcon.value
      saveIconMap(iconMap.value)
    } else {
      const res = await apiService.createCourtType({ ...payload, createdBy: '12345' })
      console.log('[createCourtType] response:', res)
      const newId = res?.data?.courtTypeId
      if (newId != null) {
        iconMap.value[newId] = selectedIcon.value
        saveIconMap(iconMap.value)
      }
    }
    closeModal()
    await fetchCourtTypes()
  } catch (error: any) {
    console.error('[saveCourtType] error:', error)
    saveError.value = error?.message ?? 'บันทึกไม่สำเร็จ กรุณาลองใหม่'
  } finally {
    saving.value = false
  }
}

// ─── API: ลบ ──────────────────────────────────────────────────────────────────
const deleteCourtType = async (id: number) => {
  if (!confirm('คุณแน่ใจหรือไม่ว่าต้องการลบประเภทสนามนี้?')) return
  try {
    await apiService.deleteCourtType(id, '12345')
    if (selectedCourtType.value?.courtTypeId === id) {
      selectedCourtType.value = null
      courts.value = []
      selectedTypeId.value = null
    }
    // ลบ icon ออกจาก map ด้วย
    delete iconMap.value[id]
    saveIconMap(iconMap.value)
    await fetchCourtTypes()
  } catch (error) {
    console.error('[deleteCourtType] error:', error)
  }
}

// ─── Modal Helpers ────────────────────────────────────────────────────────────
const openAddModal = () => {
  isEditing.value  = false
  currentId.value  = null
  selectedIcon.value = '🏟️'
  saveError.value  = ''
  form.value = { courtTypeName: '', description: '', sequence: 1, imgUuid: 'b4099451-adff-439f-94d2-3357b273045a' }
  showModal.value  = true
}

const openEditModal = (type: CourtType) => {
  isEditing.value  = true
  currentId.value  = type.courtTypeId ?? null
  selectedIcon.value = type.courtTypeId != null ? (iconMap.value[type.courtTypeId] || '🏟️') : '🏟️'
  saveError.value  = ''
  form.value = {
    courtTypeName: type.courtTypeName,
    description:   type.description,
    sequence:      type.sequence,
    imgUuid:       type.imgUuid,
  }
  showModal.value = true
}

const closeModal = () => { showModal.value = false }

// ─── Lifecycle ────────────────────────────────────────────────────────────────
onMounted(() => { fetchCourtTypes() })
</script>

<style scoped>
.page-wrapper {
  font-family: 'Sarabun', sans-serif;
  min-height: 100vh;
  background-image: url('../assets/background.png');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  display: flex;
  flex-direction: column;
}

.main-content {
  flex: 1;
  display: flex;
  gap: 24px;
  padding: 24px 28px;
}

.section-card {
  background: rgba(255,255,255,0.88);
  border-radius: 16px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.08);
  padding: 20px;
}

/* ─── Sidebar ─── */
.sidebar {
  width: 260px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
  height: fit-content;
}
.sidebar-main-title { font-size: 1.1rem; font-weight: 700; color: #1b5e20; margin-bottom: 8px; }
.select-date-label  { font-size: 0.82rem; color: #888; }
.selected-date-display { font-size: 1.5rem; font-weight: 700; color: #1a1a1a; margin-bottom: 12px; }

.calendar-widget { background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
.calendar-header { background: #26A69A; color: white; padding: 12px 16px; display: flex; justify-content: space-between; align-items: center; font-weight: 600; font-size: 0.95rem; }
.calendar-nav { display: flex; gap: 8px; }
.cal-nav-btn { background: white; border: none; color: #333; width: 24px; height: 24px; border-radius: 4px; cursor: pointer; font-weight: bold; }
.cal-weekdays { display: grid; grid-template-columns: repeat(7, 1fr); text-align: center; padding: 8px 8px 0; font-size: 0.75rem; font-weight: 700; color: #888; }
.calendar-grid { display: grid; grid-template-columns: repeat(7, 1fr); padding: 4px 8px 12px; text-align: center; }
.cal-day { padding: 7px 0; font-size: 0.82rem; cursor: pointer; border-radius: 8px; transition: background 0.15s; color: #333; }
.cal-day:hover:not(.is-empty) { background: #e8f5e9; }
.cal-day.is-selected { background: #c8e6c9; font-weight: 700; }
.cal-day.is-empty { cursor: default; }

/* ─── Right Area ─── */
.schedule-area { flex: 1; display: flex; flex-direction: column; gap: 20px; }
.top-bar { display: flex; justify-content: flex-end; }
.add-btn { background: #1b5e20; color: white; border: none; padding: 10px 20px; border-radius: 20px; font-size: 0.88rem; font-weight: 600; cursor: pointer; font-family: 'Sarabun', sans-serif; transition: background 0.2s; }
.add-btn:hover { background: #2e7d32; }

/* ─── Loading & Error ─── */
.loading-bar { height: 3px; background: linear-gradient(90deg, #1b5e20, #66bb6a, #1b5e20); background-size: 200% 100%; animation: shimmer 1.2s infinite; border-radius: 4px; margin-bottom: 12px; }
@keyframes shimmer { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }

.error-banner { background: #fff3f3; border: 1px solid #ffcdd2; color: #c62828; border-radius: 8px; padding: 10px 14px; font-size: 0.85rem; margin-bottom: 12px; }

/* ─── Tables ─── */
.table-section { overflow: hidden; }
.section-title { font-size: 1.1rem; font-weight: 700; color: #1a1a1a; margin-bottom: 2px; }
.section-sub { font-size: 0.8rem; color: #888; margin-bottom: 16px; }
.court-table { width: 100%; border-collapse: collapse; font-size: 0.88rem; }
.court-table thead tr { background: #f5f5f5; }
.court-table th { padding: 12px 16px; text-align: left; font-weight: 700; color: #555; font-size: 0.82rem; border-bottom: 2px solid #eee; }
.court-table td { padding: 14px 16px; border-bottom: 1px solid #f0f0f0; color: #333; vertical-align: middle; }
.court-table tbody tr:hover { background: #fafafa; }
.court-table tbody tr:last-child td { border-bottom: none; }
.court-icon { font-size: 1.4rem; }
.court-name-cell { font-weight: 600; }
.court-desc-cell { color: #777; }
.empty-row { text-align: center; color: #aaa; padding: 32px 0 !important; font-style: italic; }
.action-btns { display: flex; gap: 8px; }
.action-edit, .action-delete { background: none; border: none; cursor: pointer; font-size: 1rem; padding: 4px 6px; border-radius: 6px; transition: background 0.15s; }
.action-edit:hover { background: #e8f5e9; }
.action-delete:hover { background: #ffebee; }

/* ─── Sub Courts ─── */
.sub-courts-section { margin-top: 0; }
.sub-header { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 16px; flex-wrap: wrap; gap: 12px; }
.sub-controls { display: flex; align-items: flex-end; gap: 12px; }
.select-wrapper { display: flex; flex-direction: column; gap: 4px; }
.select-wrapper label { font-size: 0.78rem; color: #888; }
.type-select { border: 1px solid #ddd; border-radius: 8px; padding: 8px 12px; font-size: 0.88rem; font-family: 'Sarabun', sans-serif; min-width: 220px; cursor: pointer; background: white; }

/* ─── Modal ─── */
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.45); display: flex; align-items: center; justify-content: center; z-index: 999; }
.modal-box { background: white; border-radius: 16px; padding: 28px; width: 460px; max-width: 95vw; box-shadow: 0 8px 40px rgba(0,0,0,0.2); animation: modalPop 0.25s cubic-bezier(0.34,1.56,0.64,1); }
@keyframes modalPop { from { transform: scale(0.85); opacity: 0; } to { transform: scale(1); opacity: 1; } }
.modal-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 14px; }
.modal-header h3 { font-size: 1.1rem; font-weight: 700; color: #1a1a1a; }
.modal-close { background: none; border: none; font-size: 1.1rem; cursor: pointer; color: #888; }
.modal-body { display: flex; flex-direction: column; gap: 16px; }
.form-group { display: flex; flex-direction: column; gap: 6px; }
.form-group label { font-size: 0.82rem; font-weight: 600; color: #555; }
.form-group input { border: 1px solid #ddd; border-radius: 8px; padding: 10px 12px; font-size: 0.9rem; font-family: 'Sarabun', sans-serif; transition: border 0.2s; }
.form-group input:focus { outline: none; border-color: #2e7d32; }
.modal-footer { display: flex; justify-content: flex-end; gap: 12px; margin-top: 24px; }
.btn-cancel { background: #f5f5f5; border: none; border-radius: 8px; padding: 10px 20px; font-size: 0.88rem; font-family: 'Sarabun', sans-serif; cursor: pointer; color: #555; }
.btn-cancel:hover { background: #eee; }
.btn-confirm { background: #1b5e20; color: white; border: none; border-radius: 8px; padding: 10px 20px; font-size: 0.88rem; font-weight: 600; font-family: 'Sarabun', sans-serif; cursor: pointer; transition: background 0.2s; }
.btn-confirm:hover:not(:disabled) { background: #2e7d32; }
.btn-confirm:disabled { background: #ccc; cursor: not-allowed; }

/* ─── Icon Picker ─── */
.icon-picker { display: flex; flex-wrap: wrap; gap: 8px; }
.icon-option { font-size: 1.4rem; width: 42px; height: 42px; display: flex; align-items: center; justify-content: center; border-radius: 8px; border: 2px solid #eee; cursor: pointer; transition: all 0.15s; }
.icon-option:hover { border-color: #81c784; background: #f1f8e9; }
.icon-option.selected { border-color: #2e7d32; background: #e8f5e9; }

/* ─── Transitions ─── */
.fade-enter-active, .fade-leave-active { transition: opacity 0.2s ease; }
.fade-enter-from, .fade-leave-to { opacity: 0; }
</style>